enum TextSizes {small, medium, large}
enum OrderStatus {processing, shipped, delivered}
enum paymentMethods {paypal, googlePay, applePay, visa, masterCard, creditCard, payStack, razorPay, paytm}