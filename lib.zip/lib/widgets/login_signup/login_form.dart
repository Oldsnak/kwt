import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/constants/app_sizes.dart';
import '../../core/constants/app_strings.dart';
import '../../core/controllers/auth_controller.dart';

class LoginForm extends StatefulWidget {
  const LoginForm({super.key});

  @override
  State<LoginForm> createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final AuthController authController = Get.find<AuthController>();

  bool _isObscure = true;
  bool _rememberMe = false;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  /// ------------------------------------------------------------
  /// Helper: convert phone → salesperson email automatically
  /// ------------------------------------------------------------
  String _normalizeLoginEmail(String input) {
    final cleaned = input.trim();

    // If it's digits only → treat as salesperson login
    final isPhone = RegExp(r'^[0-9]+$').hasMatch(cleaned);

    if (isPhone && cleaned.length >= 10) {
      return "sp_$cleaned@salesperson.kwt.com";
    }

    return cleaned; // normal email
  }

  Future<void> _handleLogin() async {
    if (_formKey.currentState!.validate()) {
      final loginEmail = _normalizeLoginEmail(_emailController.text);

      try {
        await authController.signIn(
          loginEmail,
          _passwordController.text.trim(),
        );
      } catch (e) {
        Get.snackbar(
          "Login Failed",
          e.toString(),
          snackPosition: SnackPosition.BOTTOM,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: SSizes.spaceBtwSections),
        child: Column(
          children: [
            // EMAIL FIELD (UI unchanged)
            TextFormField(
              controller: _emailController,
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.email_rounded),
                labelText: STexts.email,
              ),
              validator: (value) =>
              value == null || value.isEmpty ? 'Please enter your email' : null,
            ),
            const SizedBox(height: SSizes.spaceBtwInputFields),

            // PASSWORD FIELD (UI unchanged)
            TextFormField(
              controller: _passwordController,
              obscureText: _isObscure,
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.security),
                labelText: STexts.password,
                suffixIcon: IconButton(
                  icon: Icon(_isObscure ? Icons.visibility_off : Icons.visibility),
                  onPressed: () => setState(() => _isObscure = !_isObscure),
                ),
              ),
              validator: (value) =>
              value == null || value.isEmpty ? 'Please enter your password' : null,
            ),
            const SizedBox(height: SSizes.spaceBtwInputFields / 2),

            // REMEMBER & FORGOT PASSWORD (UI unchanged)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Checkbox(
                      value: _rememberMe,
                      onChanged: (value) =>
                          setState(() => _rememberMe = value ?? false),
                    ),
                    const Text(STexts.rememberMe),
                  ],
                ),
                TextButton(
                  onPressed: () => Get.snackbar('Info', 'Password recovery coming soon'),
                  child: const Text(STexts.forgetPassword),
                ),
              ],
            ),

            const SizedBox(height: SSizes.spaceBtwSections),

            // LOGIN BUTTON (UI unchanged)
            Obx(
                  () => SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed:
                  authController.isLoading.value ? null : () => _handleLogin(),
                  child: authController.isLoading.value
                      ? const CircularProgressIndicator(
                    color: Colors.white,
                    strokeWidth: 2,
                  )
                      : const Text(STexts.signIn),
                ),
              ),
            ),

            const SizedBox(height: SSizes.spaceBtwItems),

            // CREATE ACCOUNT BUTTON (UI unchanged)
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: () => Get.snackbar('Notice', 'Signup not enabled yet'),
                child: const Text(STexts.createAccount),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
